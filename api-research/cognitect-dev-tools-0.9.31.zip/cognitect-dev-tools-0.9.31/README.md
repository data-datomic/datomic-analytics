Cognitect dev-tools
===================

# License

Use of dev-tools is contingent on the license found in the LICENSE.txt file in this directory.

# Installation

Run the install script which will install the libraries in your local maven directory.

    ./install

# Use

Cognitect dev-tools includes REBL and Datomic dev-local.

* For REBL, see https://github.com/cognitect-labs/REBL-distro.
* For dev-local, see https://docs.datomic.com/cloud/dev-local.html.
